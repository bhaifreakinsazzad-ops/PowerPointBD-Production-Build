---
name: powerpointbd-puter-studio
description: Build and verify Puter AI drafting, anime.js interactions and Three.js storyboards in PowerPointBD while preserving its server pricing and production boundaries.
---

# PowerPointBD Puter studio

Use this skill for this platform's real AI drafting and interactive studio, not unrelated OpenAI key setup or a framework migration.

- Preserve Express/TypeScript, Supabase, Python generation and the existing vanilla frontend. The user's chosen AI integration is Puter.js; a direct OpenAI key is not required for Puter browser calls.
- Inspect shared/presentation.ts and frontend/src/studio before extending the content contract. Treat model output as untrusted, plain-text content. Normalize and validate count, language, titles, bullets and notes. Do not accept AI-authored prices, entitlements, XML or tool execution.
- Discover model IDs/providers with puter.ai.listModels(); never fabricate a successful catalogue or generation fallback. Start auth from a user gesture, and disclose that requests use the user's Puter account/allowance. Submit only on deliberate generation with content-sharing consent. Do not print/store tokens or silently charge a developer account. Cancellation may not prevent provider billing for already submitted work.
- Keep draft text/Three.js storyboard separate from actual production slide-image previews and desktop PowerPoint compatibility evidence. Browser animation must never enable disabled Smooth/Cinematic effects or bypass approved content, server quotes, payment verification or private delivery.
- Use anime.js scopes for reversible UI animation and honor reduced-motion preferences. Lazy-load Three.js and Puter chunks. Dispose controls, renderer, textures and materials; stop render loops while hidden/offscreen. Keep accessible slide navigation and a usable 2D view when WebGL fails. Do not add effects merely to increase dependency count.
- A Puter response is not proof of factual accuracy, provenance or server authorization. Review and edit generated content before promoting it into the immutable production workflow. No fictional citations or fabricated customer evidence.

## Verification

Run the studio typecheck, Puter boundary tests, existing DOM tests and frontend build. Use the real browser for layout, keyboard navigation, mobile overflow and storyboard behavior. frontend/scripts/build-browser-harness.mjs generates an explicitly labeled fixture page for local interaction checks; that proves controlled UI behavior, not live AI generation. A normal build removes these temporary pages.

For live provider checks, distinguish public catalogue discovery, account authentication and actual charged generation. Never claim a stubbed SDK call proves live provider behavior. Current upstream references: https://docs.puter.com/AI/chat/ , https://docs.puter.com/AI/listModels/ , https://animejs.com/documentation/scope/ , https://threejs.org/manual/pages/how-to-dispose-of-objects.html .

Inspect docs/ROADMAP.md and current STATUS before claiming release readiness. Deployment, shared database changes and payment activation retain the existing authorization boundaries.
